### Hexlet tests and linter status:
[![Actions Status](https://github.com/Egortrod/python-project-lvl1/workflows/hexlet-check/badge.svg)](https://github.com/Egortrod/python-project-lvl1/actions)

<a href="https://codeclimate.com/github/Egortrod/project1/maintainability"><img src="https://api.codeclimate.com/v1/badges/8877bd0d9309c6fabbfb/maintainability" /></a>

https://asciinema.org/a/p0cfV9B3n3xvsXY9QP8A39gzV

https://asciinema.org/a/98TJ26CTt6zKacLP19thw9BiB